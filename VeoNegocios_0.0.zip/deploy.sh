#Run database migrations
php artisan migrate:fresh

#Run Seeds
php artisan db:seed