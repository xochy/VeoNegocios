<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>VeoNegocios</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/animation.css')); ?>" rel="stylesheet">

        <style>
            html, body {
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                background: #fff;
                color: black;
                padding: 10px 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            .home-main{
                background: #42a4f5;
                color:#fff;
                text-align: center;
            }

            .blinker{
			    animation: blinker 1.5s linear infinite;
            }

            @keyframes  blinker {
                50% {
                    opacity: 0;
                }
            }

            .home-main button{
                background: #fff;
                color: #5812c5;
                border-radius: 0;
                font-weight: 700;
                width: 16%;
                height: 50px;
                top: 4%;
                margin-top: 3%;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height home-main">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Inicio</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Ingreso</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Registro</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md animated pulse">
                    VeoNegocios<span class="blinker">.</span>com
                </div>

                <div class="links">
                    <a href="<?php echo e(route('categories.index')); ?>">Categorías</a>
                    <a href="<?php echo e(route('stores.index')); ?>">Negocios</a>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/welcome.blade.php ENDPATH**/ ?>