    
<?php $__env->startSection('titulo', 'Editar negocio'); ?>
<?php $__env->startSection('content'); ?>
<h3>Edición de negocio <?php echo e($store->name); ?></h3>

<nav aria-label="breadcrumb">
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>">Categorías</a></li>
        <li class="breadcrumb-item"><a href="/categories/<?php echo e($store->category->slug); ?>"><?php echo e($store->category->name); ?></a></li>
		<li class="breadcrumb-item active" aria-current="page"><?php echo e($store->name); ?></li>
	</ol>
</nav>

<div class="card">
    <div class="card-header">Formulario de edición de negocio
        <small id="scheduleHelp" class="form-text text-muted">Los campos obligatorios están marcados con el símbolo <i class="fas fa-star-of-life colorFormRequiredIcon"></i></small>
    </div>
    <div class="card-body">
        <form class="form-group" method="POST" action="<?php echo e(route('stores.update', $store->slug)); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('stores.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <button type="submit" class="btn btn-primary"><i class="far fa-save"></i> Actualizar</button>
            <a href="<?php echo e(route('stores.cancelAction', $store)); ?>" class="redondo btn btn-danger"><i class="fas fa-ban"></i> Cancelar</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/stores/edit.blade.php ENDPATH**/ ?>