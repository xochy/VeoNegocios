<div class="row">
    <div class="col-md-12">    
        <nav>
            <div class="nav nav-pills nav-fill" id="nav-tab" role="tablist">
                <?php $__empty_1 = true; $__currentLoopData = $store->networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a class="nav-item nav-link btn btn-<?php echo e(App\Contact::where('id', $network->contact_id)->first()->color); ?> <?php if($loop->first): ?> active <?php endif; ?>" id="nav-<?php echo e($loop->iteration); ?>-tab" data-toggle="tab" href="#nav-<?php echo e($loop->iteration); ?>" role="tab"
                    aria-controls="nav-<?php echo e($loop->iteration); ?>" aria-selected="true"><i class="<?php echo e(App\Contact::where('id', $network->contact_id)->first()->iconClass); ?>"></i> <?php echo e(App\Contact::where('id', $network->contact_id)->first()->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h6 class="mt-3">No existen contactos 
                        <?php if(Auth::user()->authorizeRolesShow(['administrator', 'collector', 'costumer'])): ?>
                            <span class="badge badge-warning">Puede hacer clic en el botón de arriba para agregar un nuevo contacto</span>
                        <?php endif; ?>
                    </h6>
                <?php endif; ?>
            </div>
        </nav>
        <div class="tab-content" id="nav-tabContent">
            <?php $__currentLoopData = $store->networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php if($loop->first): ?>show active <?php endif; ?>" id="nav-<?php echo e($loop->iteration); ?>" role="tabpanel" aria-labelledby="nav-<?php echo e($loop->iteration); ?>-tab">
                    <div class="card mb-3">
                        <?php if(App\Contact::where('name', 'YouTube')->first()->id == $network->contact_id): ?>
                            <div class="embed-responsive embed-responsive-16by9">
                                <iframe class="embed-responsive-item" src="<?php echo e($network->description); ?>" allowfullscreen></iframe>
                            </div>
                        <?php elseif(App\Contact::where('name', 'Facebook')->first()->id == $network->contact_id): ?>
                            <div class="col-xs-1 text-center">
                                <div class="fb-page" data-href="<?php echo e($network->description); ?>" data-tabs="timeline" data-width="350" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="<?php echo e($network->description); ?>" class="fb-xfbml-parse-ignore"><a href="<?php echo e($network->description); ?>">Radioactive Streaming</a></blockquote></div>
                            </div>
                        <?php else: ?>
                        <div class="container">
                            <h4><?php echo e($network->description); ?></h4>
                        </div>
                        <?php endif; ?>
                        <?php if(Auth::user() != null && Auth::user()->authorizeRolesShow(['administrator', 'collector', 'costumer'])): ?>
                            <div class="card-footer">
                                <small class="text-muted">Agregado el <?php echo e($network->created_at); ?> </small><br>
                                <small class="text-muted">Última modificación: <?php echo e($network->updated_at); ?> </small><br><br>
                                <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('networks.edit', $network->id )); ?>"><i class="far fa-edit"></i> Editar</a>
                                <a class="btn btn-outline-danger btn-sm" href="<?php echo e(route('networks.confirmAction', $network->id )); ?>"><i class="far fa-trash-alt"></i> Eliminar</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/networks/list.blade.php ENDPATH**/ ?>