<?php $__env->startSection('titulo', 'Elminar negocio'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h1>¿Desea eliminar el negocio <?php echo e($store->name); ?>?</h1>
    <form method="POST" action="<?php echo e(route('stores.destroy', $store->slug)); ?>">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <button type="submit" class="redondo btn btn-danger">
            <i class="fas fa-trash-alt"></i> Eliminar
        </button>
        <a class="redondo btn btn-secondary" href="<?php echo e(route('stores.cancelAction', $store->slug)); ?>">
            <i class="fas fa-ban"></i> Cancelar
        </a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/stores/confirmAction.blade.php ENDPATH**/ ?>