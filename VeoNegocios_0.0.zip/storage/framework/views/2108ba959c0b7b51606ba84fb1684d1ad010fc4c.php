<?php $__env->startSection('titulo', 'Elminar contacto'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h1>¿Desea eliminar el contacto correspondiente a <?php echo e($network->description); ?>?</h1>
    <form method="POST" action="<?php echo e(route('networks.destroy', $network->id)); ?>">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <button type="submit" class="redondo btn btn-danger">
            <i class="fas fa-trash-alt"></i> Eliminar
        </button>
        <a class="redondo btn btn-secondary" href="<?php echo e(route('networks.cancelAction', $network->id)); ?>">
            <i class="fas fa-ban"></i> Cancelar
        </a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/networks/confirmAction.blade.php ENDPATH**/ ?>