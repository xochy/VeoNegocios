<?php $__env->startSection('titulo', 'Detalles de categoría'); ?>
<?php $__env->startSection('content'); ?>
<h3>Detalles de la categoría <?php echo e($category->name); ?></h3>

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
		<li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>">Categorías</a></li>
		<li class="breadcrumb-item active" aria-current="page"><?php echo e($category->name); ?></li>
	</ol>
</nav>

<?php if(session('statusSuccess')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('statusSuccess')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(session('statusCancel')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('statusCancel')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<div class="jumbotron text-center hoverable p-4">
    <div class="row">
        <div class="col-md-4 offset-md-1 mx-3 my-3">
            <div class="view overlay">
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">

                    <?php $__currentLoopData = $category->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item 
                        <?php if($loop->first): ?>
                            active">
                        <?php else: ?>
                        ">
                        <?php endif; ?> <img src="/images/<?php echo e($image->url); ?>" class="d-block w-100" alt="...">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>                    
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>

        </div>
        <div class="col-md-7 text-md-left ml-3 mt-3">
            

            <h4 class="h4 mb-4"><?php echo e($category->name); ?></h4>

            <p class="font-weight-normal"><?php echo e($category->description); ?></p>
            
            <?php if(Auth::user() != null && Auth::user()->authorizeRolesShow(['administrator', 'collector'])): ?>
                <a  class="btn btn-primary" href="<?php echo e(route('stores.createFromCategory', $category->slug)); ?>"><i class="far fa-plus-square"></i> Crear nuevo negocio</a>
            <?php endif; ?>
            
            <?php if(Auth::user() != null && Auth::user()->authorizeRolesShow('administrator')): ?>
                <a class="btn btn-warning" href="<?php echo e(route('categories.edit', $category->slug )); ?>" ><i class="far fa-edit"></i> Editar categoría</a>
                <a class="btn btn-danger" href="<?php echo e(route('categories.confirmAction', $category->slug )); ?>"><i class="far fa-trash-alt"></i> Eliminar categoría</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<h3 style="margin-bottom: -35px;">Lista de Negocios</h3>
<?php echo $__env->make('stores.list', ['stores' => $category->stores], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/categories/show.blade.php ENDPATH**/ ?>