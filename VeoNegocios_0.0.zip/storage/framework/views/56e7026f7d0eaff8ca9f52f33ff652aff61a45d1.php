<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $store->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-4 mt-3">
            <div class="card h-100 d-flex flex-column justify-content-between">
                <div class="card-img">
                    <img class="card-img-top" src="/images/<?php echo e($product->images->first()->url); ?>" alt="Card image cap">
                    <?php if($product->offered == 1): ?> <span><h4>Oferta</h4></span> <?php endif; ?>
                </div>             
                <div class="card-block p-3">
                    <h5 class="card-title"><?php echo e($product->name); ?></h5>
                    <p class="card-text"><?php echo e($product->description); ?></p>
                    <h2><?php echo e($product->price); ?></h2>
                    <a href="#" class="btn btn-primary mb-2">Ver más...</a>
                </div>
                <?php if(Auth::user() != null && Auth::user()->authorizeRolesShow(['administrator', 'collector', 'costumer'])): ?>
                    <div class="card-footer">
                        <small class="text-muted">Agregado el <?php echo e($product->created_at); ?> </small><br>
                        <small class="text-muted">Última modificación: <?php echo e($product->updated_at); ?> </small><br><br>
                        <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('products.edit', $product->slug )); ?>"><i class="far fa-edit"></i> Editar</a>
                        <a class="btn btn-outline-danger btn-sm" href="<?php echo e(route('products.confirmAction', $product->slug )); ?>"><i class="far fa-trash-alt"></i> Eliminar</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="container">
            <h6>No existen productos 
                <?php if(Auth::user() != null && Auth::user()->authorizeRolesShow(['administrator', 'collector', 'costumer'])): ?>
                    <span class="badge badge-warning">Puede hacer clic en el botón de arriba para agregar un nuevo producto</span>
                <?php endif; ?>
            </h6>
        </div>
    <?php endif; ?>
</div><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/products/list.blade.php ENDPATH**/ ?>