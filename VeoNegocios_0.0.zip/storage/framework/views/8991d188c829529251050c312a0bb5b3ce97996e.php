    
<?php $__env->startSection('titulo', 'Crear categoría'); ?>
<?php $__env->startSection('content'); ?>
<h3>Registro de dirección</h3>

<nav aria-label="breadcrumb">
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>">Categorías</a></li>
        <li class="breadcrumb-item"><a href="/categories/<?php echo e($store->category->slug); ?>"><?php echo e($store->category->name); ?></a></li>
        <li class="breadcrumb-item"><a href="/stores/<?php echo e($store->slug); ?>"><?php echo e($store->name); ?></a></li>
		<li class="breadcrumb-item active" aria-current="page">Agregar nueva dirección</li>
	</ol>
</nav>

<div class="card">
    <div class="card-header">Formulario de registro de dirección
        <small id="scheduleHelp" class="form-text text-muted">Los campos obligatorios están marcados con el símbolo <i class="fas fa-star-of-life colorFormRequiredIcon"></i></small>
    </div>
    <div class="card-body">
        <form class="form-group" method="POST" action="<?php echo e(route('addresses.storeFromStore', $store->slug)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('addresses.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <button type="submit" class="btn btn-primary"><i class="far fa-save"></i> Guardar</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/addresses/create.blade.php ENDPATH**/ ?>