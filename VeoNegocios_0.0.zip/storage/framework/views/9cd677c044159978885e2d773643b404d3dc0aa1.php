    
<?php $__env->startSection('titulo', 'Editar dirección'); ?>
<?php $__env->startSection('content'); ?>
<h3>Edición del contacto correspondiente a <?php echo e($network->description); ?></h3>

<nav aria-label="breadcrumb">
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>">Categorías</a></li>
        <li class="breadcrumb-item"><a href="/categories/<?php echo e($network->store->category->slug); ?>"><?php echo e($network->store->category->name); ?></a></li>
        <li class="breadcrumb-item"><a href="/stores/<?php echo e($network->store->slug); ?>"><?php echo e($network->store->name); ?></a></li>
		<li class="breadcrumb-item active" aria-current="page">Contacto: <?php echo e($network->description); ?></li>
	</ol>
</nav>

<div class="card">
    <div class="card-header">Formulario de edición de contacto</div>
    <div class="card-body">
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form class="form-group" method="POST" action="<?php echo e(route('networks.update', $network->id)); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('networks.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <button type="submit" class="btn btn-primary"><i class="far fa-save"></i> Actualizar</button>
            <a href="<?php echo e(route('networks.cancelAction', $network)); ?>" class="redondo btn btn-danger"><i class="fas fa-ban"></i> Cancelar</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/networks/edit.blade.php ENDPATH**/ ?>