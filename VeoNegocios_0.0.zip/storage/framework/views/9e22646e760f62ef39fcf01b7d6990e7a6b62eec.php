<?php $__env->startSection('titulo', 'Detalles de negocio'); ?>
<?php $__env->startSection('content'); ?>
<h3>Detalles del negocio <?php echo e($store->name); ?></h3>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>">Categorías</a></li>
        <li class="breadcrumb-item"><a href="/categories/<?php echo e($store->category->slug); ?>"><?php echo e($store->category->name); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($store->name); ?></li>
    </ol>
</nav>
  
<?php if(session('statusSuccess')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('statusSuccess')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(session('statusCancel')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('statusCancel')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-8">
                <div class="card mb-3">
                    <div class="carousel slide" id="carousel-667320">
                        <ol class="carousel-indicators">    
                            <?php $__currentLoopData = $store->images->where('position', '>', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($store->images->where('position', '>', 0)->count() > 1): ?>                       
                                    <li data-slide-to="<?php echo e($image->position - 1); ?>" data-target="#carousel-667320" <?php if($loop->first): ?> class="active" <?php endif; ?>>
                                <?php endif; ?>                 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $store->images->where('position', '>', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php if($loop->first): ?>
                                    active
                                <?php endif; ?>">
                                    <img class="d-block w-100" alt="Carousel Bootstrap First" src="/images/<?php echo e($image->url); ?>" />
                                    <?php if(isset($image->tittle) || isset($image->description)): ?>
                                        <div class="carousel-caption panel-transparent">
                                            <h4><?php if(isset($image->tittle)): ?><?php echo e($image->tittle); ?><?php endif; ?></h4>
                                            <p><?php if(isset($image->description)): ?><?php echo e($image->description); ?><?php endif; ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> 

                        <?php if($store->images->where('position', '>', 0)->count() > 1): ?>
                            <a class="carousel-control-prev" href="#carousel-667320" data-slide="prev"><span class="carousel-control-prev-icon"></span> 
                                <span class="sr-only">Anterior</span></a> <a class="carousel-control-next" href="#carousel-667320" data-slide="next">
                                <span class="carousel-control-next-icon"></span> <span class="sr-only">Siguiente</span>
                            </a>
                        <?php endif; ?>                      
                       
                    </div>
                    <div class="card-body">
                        <div class="d-flex bd-highlight">
                            <div class="p-2 flex-grow-1 bd-highlight"><h2 class="card-title"><?php echo e($store->name); ?></h2></div>
                            <div class="p-2 bd-highlight"><h2><?php echo e(number_format((float)$store->score, 1, '.', '')); ?></h2></div>
                            <div class="p-2 bd-highlight">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <span class="align-middle fa fa-star fa-lg <?php if($store->score >= $i): ?> checked <?php endif; ?>" id="star<?php echo e($i); ?>"></span>
                                <?php endfor; ?>
                            </div>
                        </div>
                        <p class="card-text"><?php echo e($store->description); ?></p>
                        <a href="#productList" class="card-text green-text">
                            <h6 class="h6 pb-1"><i class="fas fa-cash-register"></i> <?php echo e($store->products->count()); ?> productos/servicios que ofrece este negocio</h6>
                        </a>
                    </div>
                    <?php if(Auth::user() != null && Auth::user()->authorizeRolesShow(['administrator', 'collector', 'costumer'])): ?>
                        <div class="card-footer">
                            <small class="text-muted">Agregado el <?php echo e($store->created_at); ?> </small><br>
                            <small class="text-muted">Última modificación: <?php echo e($store->updated_at); ?> </small><br><br>
                            <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('stores.edit', $store->slug )); ?>" ><i class="far fa-edit"></i> Editar</a>
                            <a class="btn btn-outline-danger btn-sm" href="<?php echo e(route('stores.confirmAction', $store->slug )); ?>"><i class="far fa-trash-alt"></i> Eliminar</a>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="mt-3 mb-3">          
                    <h3 class="display-5 text-center"> Contactos y Redes sociales </h3>
                    <hr class="bg-dark mb-4 w-25">

                    <?php if($store->networks()->count() < 4): ?>
                        <?php if(Auth::user() != null && Auth::user()->authorizeRolesShow(['administrator', 'collector', 'costumer'])): ?>
                            <a class="btn btn-outline-success btn-sm" style="margin-bottom: 10px;" href="<?php echo e(route('networks.createFromStore', $store->slug)); ?>"><i class="far fa-plus-square"></i> Agregar nuevo contacto</a>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php echo $__env->make('networks.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="mt-4 mb-3">
                    <h3 class="display-5 text-center"> Direcciones </h3>
                    <hr class="bg-dark mb-4 w-25">

                    <?php if($store->addresses()->count() < 3): ?>
                        <?php if(Auth::user() != null && Auth::user()->authorizeRolesShow(['administrator', 'collector', 'costumer'])): ?>
                            <a class="btn btn-outline-success btn-sm" style="margin-bottom: 10px;" href="<?php echo e(route('addresses.createFromStore', $store->slug)); ?>"><i class="far fa-plus-square"></i> Agregar nueva dirección</a>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php echo $__env->make('addresses.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-md-4">
                <h3 class="display-5 text-center"> Comentarios </h3>
                <hr class="bg-dark mb-4 w-25">                
                <?php echo $__env->make('comments.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if(Auth::user() != null && Auth::user()->authorizeRolesShow(['administrator', 'viewer'])): ?>
                    <a class="btn btn-outline-success btn-sm" style="margin: 10px 0 10px 0; width: 100%;" href="<?php echo e(route('comments.createFromStore', $store->slug)); ?>"><i class="far fa-plus-square"></i> Agregar comentario</a>
                <?php else: ?>
                    <a class="btn btn-warning btn-sm" style="margin: 10px 0 10px 0; width: 100%;" href="<?php echo e(route('login')); ?>"><i class="fas fa-sign-in-alt"></i> Ingresa con tu usuario para dejar un comentario</a>
                <?php endif; ?>
            </div>
        </div>
        <div id="productList" class="row">
            <div class="col-md-12">
                <h3 class="display-5 text-center"> Productos/Servicios </h3>
                    <hr class="bg-dark mb-4 w-25">
                    <?php if(Auth::user() != null && Auth::user()->authorizeRolesShow(['administrator', 'collector', 'costumer'])): ?>
                        <a class="btn btn-outline-success btn-sm" style="margin-bottom: 10px;" href="<?php echo e(route('products.createFromStore', $store->slug)); ?>"><i class="far fa-plus-square"></i> Agregar nuevo producto</a>
                    <?php endif; ?>
                    <?php echo $__env->make('products.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>

<script async defer crossorigin="anonymous" src="https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v6.0"></script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/stores/show.blade.php ENDPATH**/ ?>