<?php $__env->startSection('titulo', 'Negocios'); ?>
<?php $__env->startSection('content'); ?>
    <h3 class="display-5 text-center"> Negocios </h3>
    <hr class="bg-dark mb-4 w-25">
    <?php echo $__env->make('stores.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/stores/index.blade.php ENDPATH**/ ?>