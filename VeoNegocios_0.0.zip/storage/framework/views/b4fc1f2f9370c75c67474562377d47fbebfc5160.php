<?php $__env->startSection('titulo', 'Elminar producto'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h1>¿Desea eliminar el producto <?php echo e($product->name); ?>?</h1>
    <form method="POST" action="<?php echo e(route('products.destroy', $product->slug)); ?>">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <button type="submit" class="redondo btn btn-danger">
            <i class="fas fa-trash-alt"></i> Eliminar
        </button>
        <a class="redondo btn btn-secondary" href="<?php echo e(route('products.cancelAction', $product->slug)); ?>">
            <i class="fas fa-ban"></i> Cancelar
        </a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/products/confirmAction.blade.php ENDPATH**/ ?>