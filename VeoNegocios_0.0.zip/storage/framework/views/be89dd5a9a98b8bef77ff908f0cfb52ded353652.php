<nav>
    <div class="nav nav-pills nav-fill" id="nav-tab" role="tablist">
        <a class="nav-item nav-link btn btn-info active" id="nav-phone-tab" data-toggle="tab" href="#nav-phone" role="tab"
            aria-controls="nav-phone" aria-selected="true"><i class="fas fa-phone"></i> Teléfono</a>

        <a class="nav-item nav-link btn btn-success" id="nav-whatsapp-tab" data-toggle="tab" href="#nav-whatsapp" role="tab"
            aria-controls="nav-whatsapp" aria-selected="false"><i class="fab fa-whatsapp"></i> WhatsApp</a>

        <a class="nav-item nav-link btn btn-primary" id="nav-facebook-tab" data-toggle="tab" href="#nav-facebook" role="tab"
            aria-controls="nav-facebook" aria-selected="false"><i class="fab fa-facebook-square"></i></i> Facebook</a>

        <a class="nav-item nav-link btn btn btn-danger" id="nav-youtube-tab" data-toggle="tab" href="#nav-youtube" role="tab"
            aria-controls="nav-youtube " aria-selected="false"><i class="fab fa-youtube"></i> YouTube</a>
    </div>
</nav>
<div class="tab-content" id="nav-tabContent">
    <div class="tab-pane fade show active" id="nav-phone" role="tabpanel" aria-labelledby="nav-phone-tab">
        <div class="container">
            Números telefónicos    
        </div>
    </div>
    <div class="tab-pane fade" id="nav-whatsapp" role="tabpanel" aria-labelledby="nav-whatsapp-tab">Whastapp</div>
    <div class="tab-pane fade" id="nav-facebook" role="tabpanel" aria-labelledby="nav-facebook-tab">link de facebook</div>
    <div class="tab-pane fade" id="nav-youtube" role="tabpanel" aria-labelledby="nav-youtube-tab">
        <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/zpOULjyy-n8?rel=0" allowfullscreen></iframe>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/contacts/list.blade.php ENDPATH**/ ?>