<div class="row" id="accordionStore">     
    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mt-5">
            <div class="card text-center h-100 d-flex flex-column justify-content-between">
                <div class="card-img">
                    <a href="/stores/<?php echo e($store->slug); ?>">
                        <img class="card-img-top" src="/images/<?php echo e($store->images->first()->url); ?>" alt="Card image cap">
                        <span style="background: #2e84d1;"><h4><i class="fas fa-star"></i> <?php echo e(number_format((float)$store->score, 1, '.', '')); ?></h4></span>
                    </a>
                </div>
                <div class="card-body">
                    <h4 class="card-title"><?php echo e($store->name); ?></h4>
                    <button style="margin: 10px 0 10px 0; width: 100%;" type="button" class="btn btn-primary" data-toggle="modal" 
                    data-target="#example<?php echo e($store->slug); ?>" onclick="loadMap(<?php echo e($store->addresses); ?>)">
                        <i class="fas fa-info-circle fa-lg"></i> Ver detalles de sucursales...
                    </button>

                    <div class="modal fade" id="example<?php echo e($store->slug); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($store->name); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p class="font-weight-normal mt-3"><?php echo e($store->description); ?></p>
                                    <nav>
                                        <div class="nav nav-pills nav-fill" id="nav-tab" role="tablist">
                                            <?php $__currentLoopData = $store->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($loop->first): ?>
                                                    <a class="nav-item nav-link active btn btn-info" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab"
                                                    aria-controls="nav-home" aria-selected="true">Sucursal 1</a>
                                                <?php else: ?>
                                                    <a class="nav-item nav-link btn btn-info" id="nav-profile-tab<?php echo e($address->slug); ?>" data-toggle="tab" href="#nav-profile<?php echo e($address->slug); ?>" role="tab"
                                                    aria-controls="nav-profile" aria-selected="false">Sucursal <?php echo e($loop->iteration); ?></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                                        </div>
                                    </nav>
                                    <div class="tab-content">
                                        <?php $__currentLoopData = $store->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tab-pane fade <?php if($loop->first): ?>show active <?php endif; ?>" <?php if($loop->first): ?> id="nav-home" <?php else: ?> id="nav-profile<?php echo e($address->slug); ?>" <?php endif; ?> role="tabpanel" <?php if($loop->first): ?> aria-labelledby="nav-home-tab" <?php else: ?> aria-labelledby="nav-profile-tab<?php echo e($address->slug); ?>" <?php endif; ?>>
                                                <div class="card mb-3">
                                                    <div style="height: 250px">
                                                        <div id="<?php echo e($address->slug); ?>" class="map"></div>
                                                    </div>
                                                    <div class="card-body">
                                                        <h5 class="card-title"><?php echo e($address->address_address); ?></h5>
                                                        <p class="card-text"><?php echo e($address->reference); ?></p>
                                                        <p class="card-text"><small class="text-muted"><i class="fas fa-clock"></i> <?php echo e($address->schedule); ?></small></p>
                                                    </div>
                                                </div>                    
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>  
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                    <a href="/stores/<?php echo e($store->slug); ?>" role="button" class="btn btn-success">Visitar <?php echo e($store->name); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-muted">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $store->networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <?php if(App\Contact::where('name', 'YouTube')->first()->id == $network->contact_id || App\Contact::where('name', 'Facebook')->first()->id == $network->contact_id): ?>
                                <div class="col">
                                    <a href="<?php echo e($network->description); ?>"><i class="<?php echo e(App\Contact::where('id', $network->contact_id)->first()->iconClass); ?> colorStoreRequiredIcon fa-lg"></i></a>
                                </div>
                            <?php else: ?>
                                <div class="col">
                                    <a tabindex="0" role="button" data-toggle="popover" data-trigger="focus" title="<?php echo e(App\Contact::where('id', $network->contact_id)->first()->name); ?>"
                                        data-content="<?php echo e($network->description); ?>">
                                        <i class="<?php echo e(App\Contact::where('id', $network->contact_id)->first()->iconClass); ?> colorStoreRequiredIcon fa-lg"></i></a>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col">
                                <a tabindex="0" role="button" data-toggle="popover" data-trigger="focus" title="Contactos/Redes Sociales" data-content="No se han agregado contanctos ni redes sociales"><i class="fas fa-phone-slash colorStoreRequiredIcon fa-lg"></i></a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php if($stores instanceof \Illuminate\Pagination\LengthAwarePaginator): ?>
    <hr>
    <?php echo e($stores->links()); ?>

<?php endif; ?>


<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCRs1LSFxl7j1LCaiOU_CNO3r5N0PTxCY4&libraries=places" async defer ></script>
<script>
    $(function () {
        $('[data-toggle="popover"]').popover()
    })

    function loadMap(addresses, slug) {
        addresses.forEach(address => {
            myLatlng = new google.maps.LatLng(address.address_latitude, address.address_longitude);

            var myOptions = { 
                    zoom: 15, 
                    center: myLatlng,   
                    mapTypeId: google.maps.MapTypeId.ROADMAP,
                    zoomControl: true,
                    mapTypeControl: false,
                    disableDefaultUI: true,
                    types: ['(cities)'],
                    componentRestrictions: {country: 'mx'}
                }

                map = new google.maps.Map(document.getElementById(address.slug), myOptions);

                marker = new google.maps.Marker({ 
                    position: myLatlng, 
                    draggable: false
                });

                marker.setMap(map); 
        });
    }
</script>

<?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/stores/list.blade.php ENDPATH**/ ?>