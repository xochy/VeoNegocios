<?php $__env->startSection('titulo', 'Elminar dirección'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h1>¿Desea eliminar la dirección correspondiente a <?php echo e($address->address_address); ?>?</h1>
    <form method="POST" action="<?php echo e(route('addresses.destroy', $address->slug)); ?>">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <button type="submit" class="redondo btn btn-danger">
            <i class="fas fa-trash-alt"></i> Eliminar
        </button>
        <a class="redondo btn btn-secondary" href="<?php echo e(route('addresses.cancelAction', $address->slug)); ?>">
            <i class="fas fa-ban"></i> Cancelar
        </a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/addresses/confirmAction.blade.php ENDPATH**/ ?>