<div class="form-group">
    <i class="fas fa-star-of-life colorFormRequiredIcon fa-xs"></i> <label for="">Nombre</label>
    <div class="input-group">
        <div class="input-group-prepend">
            <span class="input-group-text" id="imageGroup1"><i class="fas fa-object-group"></i></span>
        </div>
        <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
        value="<?php if(isset($category->name)): ?><?php echo e($category->name); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>" autofocus>

        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>   
</div>
<div class="form-group">
    <i class="fas fa-star-of-life colorFormRequiredIcon fa-xs"></i> <label for="">Descripción</label>
    <div class="input-group">
        <div class="input-group-prepend">
            <span class="input-group-text" id="imageGroup1"><i class="fas fa-tag"></i></span>
        </div>
        <input type="text" name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
        value="<?php if(isset($category->description)): ?><?php echo e($category->description); ?><?php else: ?><?php echo e(old('description')); ?><?php endif; ?>">

        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>    
</div>
<?php if(isset($category->images)): ?>
<div class="form-group">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        Ya se han seleccionado <strong>imágenes</strong> <i class="fas fa-image"></i> para la categoría, si desea cambiarlas, puede hacerlo seleccionando nuevos archivos.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
</div>
<?php endif; ?>
<div class="form-row">
    <div class="form-group col-md-6">    
        <i class="fas fa-star-of-life colorFormRequiredIcon fa-xs"></i> <label for="">Imagen 1</label>
        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text" id="imageGroup1"><i class="fas fa-file-image"></i></span>
            </div>
            <div class="custom-file">                
                <input type="file" class="custom-file-input <?php $__errorArgs = ['image1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="image1" lang="es" name="image1" aria-describedby="imageGroup1">                
                <label class="custom-file-label" for="image1">Seleccionar Archivo</label>

                <?php $__errorArgs = ['image1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-tooltip" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                
            </div>
        </div>   
    </div>
    <div class="form-group col-md-6">
        <i class="fas fa-star-of-life colorFormRequiredIcon fa-xs"></i> <label for="">Imagen 2</label>
        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text" id="imageGroup2"><i class="fas fa-file-image"></i></span>
            </div>
            <div class="custom-file">                
                <input type="file" class="custom-file-input <?php $__errorArgs = ['image2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="image2" lang="es" name="image2" aria-describedby="imageGroup2">
                <label class="custom-file-label" for="image2">Seleccionar Archivo</label>

                <?php $__errorArgs = ['image2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-tooltip" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                
            </div>    
        </div>   
    </div>
</div>
<div class="form-row">
    <div class="form-group col-md-6">
        <div class="col text-center">
            <figure class="figure">
                <img class="img-fluid img-thumbnail" id="previewImage1" style="width: 250px; height: 150px; object-fit:cover;"
                <?php if(isset($category->images)): ?> src="<?php echo e('/images/' . $category->images->where('position', 1)->first()->url); ?>" <?php endif; ?> />
                <figcaption class="figure-caption">Vista previa de imagen 1</figcaption>
            </figure>
        </div>
    </div>
    <div class="form-group col-md-6">
        <div class="col text-center">
            <figure class="figure">
                <img class="img-fluid img-thumbnail" id="previewImage2" style="width: 250px; height: 150px; object-fit:cover;"
                <?php if(isset($category->images)): ?> src="<?php echo e('/images/' . $category->images->where('position', 2)->first()->url); ?>" <?php endif; ?> />
                <figcaption class="figure-caption">Vista previa de imagen 2</figcaption>
            </figure>
        </div>
    </div>
</div>

<script>
    $('#image1').change(function(){setFileName($(this));readURL(this, '#previewImage1');});
    $('#image2').change(function(){setFileName($(this));readURL(this, '#previewImage2');});

    function setFileName(input){
        var fileName = input.val();
        input.next('.custom-file-label').html(fileName.replace(/^.*\\/, ""));
    }

    function readURL(input, frame) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
        
            reader.onload = function(e) {
                $(frame).attr('src', e.target.result);
            }
    
            reader.readAsDataURL(input.files[0]);
        }
    }
</script><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/categories/form.blade.php ENDPATH**/ ?>