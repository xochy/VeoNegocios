<?php $__env->startSection('titulo', 'Categorías'); ?>
<?php $__env->startSection('content'); ?>
<h3>Categorías</h3>

<nav aria-label="breadcrumb">
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
		<li class="breadcrumb-item active" aria-current="page">Categorías</li>
	</ol>
</nav>

<?php if(session('statusSuccess')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('statusSuccess')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(session('statusCancel')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('statusCancel')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(Auth::user() != null && Auth::user()->authorizeRolesShow('administrator')): ?>
    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary"><i class="far fa-plus-square"></i> Crear nueva categoría</a>
<?php endif; ?>

<div class="row mt-3">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 col-sm-6">
        <div class="product-grid2">
            <div class="product-image2">
                <a href="/categories/<?php echo e($category->slug); ?>">
                    <?php $__currentLoopData = $category->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img <?php if($loop->first): ?>
                            class="pic-1"
                        <?php else: ?>
                            class="pic-2"
                        <?php endif; ?> src="/images/<?php echo e($image->url); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </a>
                <a class="add-to-cart" href="/categories/<?php echo e($category->slug); ?>">Ver más...</a>
            </div>
            <div class="product-content">
                <h3 class="title"><a href="#"><?php echo e($category->name); ?></a></h3>
                <span class="price"><?php echo e($category->description); ?></span>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/categories/index.blade.php ENDPATH**/ ?>