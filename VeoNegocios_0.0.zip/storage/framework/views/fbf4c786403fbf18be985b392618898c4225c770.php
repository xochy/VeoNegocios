<div class="list-group">
    <?php $__empty_1 = true; $__currentLoopData = $store->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a class="list-group-item">
            <div class="d-flex w-100 justify-content-between">
                <h5 class="mb-1 text-primary"><?php echo e(App\User::where('id', $comment->user_id)->first()->name); ?></h5>
                <small>
                    <?php for($i = 1; $i <= 5; $i++): ?>
                    <span class="fa fa-star <?php if($comment->score >= $i): ?> checked <?php endif; ?>" id="star<?php echo e($i); ?>"></span>
                    <?php endfor; ?>
                </small>
            </div>
            <p class="mb-1"><?php echo e($comment->description); ?>.</p>
            <small class="text-muted"><i class="far fa-clock"></i> Agregado el <?php echo e($comment->created_at); ?> </small>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h6 class="mt-3">No existen comentarios 
        <?php if(Auth::user()->authorizeRolesShow(['administrator', 'viewer'])): ?>
            <span class="badge badge-warning">Puede hacer clic en el botón de abajo para agregar un nuevo comentario</span>
        <?php endif; ?>
    </h6>
    <?php endif; ?>
</div>

<style>
    .checked {
        color: orange;
    }

    .list-group{
        max-height: 1000px;
        margin-bottom: 10px;
        overflow:scroll;
        -webkit-overflow-scrolling: touch;
        overflow-x: hidden;
        overflow-y: auto;
    }
</style>

<script>
    function add(ths,sno){

    for (var i=1;i<=5;i++){ 
        var cur=document.getElementById("star"+i) 
        cur.className="fa fa-star" 
    } 
    
    for (var i=1;i<=sno;i++){
        var cur=document.getElementById("star"+i) 
        if(cur.className=="fa fa-star" ) { cur.className="fa fa-star checked" } }
    }
</script><?php /**PATH C:\laragon\www\VeoNegocios\VeoNegocios_0.0\resources\views/comments/list.blade.php ENDPATH**/ ?>